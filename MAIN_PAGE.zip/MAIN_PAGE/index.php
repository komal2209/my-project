<!DOCTYPE html>
<html>
<title></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="style.css">
<body>

<!-- Navbar (sit on top) -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-card" id="myNavbar">
   
    <!-- Right-sided navbar links -->
    <div class="w3-right w3-hide-small">
      <a href="#about" class="w3-bar-item w3-button"><i class="fa fa-edit"></i>ABOUT</a>
      <a href="#team" class="w3-bar-item w3-button"><i class="fa fa-user"></i> TEAM</a>
      <a href="#work" class="w3-bar-item w3-button"><i class="fa fa-th"></i> WORK</a>
      <a href="#contact" class="w3-bar-item w3-button"><i class="fa fa-envelope"></i> CONTACT</a>
    </div>
    <!-- Hide right-floated links on small screens and replace them with a menu icon -->

    <a href="javascript:void(0)" class="w3-bar-item w3-button w3-right w3-hide-large w3-hide-medium" onclick="w3_open()">
      <i class="fa fa-bars"></i>
    </a>
  </div>
</div>

<!-- Sidebar on small screens when clicking the menu icon -->
<nav class="w3-sidebar w3-bar-block w3-black w3-card w3-animate-left w3-hide-medium w3-hide-large" style="display:none" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" class="w3-bar-item w3-button w3-large w3-padding-16">Close ×</a>
  <a href="#about" onclick="w3_close()" class="w3-bar-item w3-button">ABOUT</a>
  <a href="#team" onclick="w3_close()" class="w3-bar-item w3-button">TEAM</a>
  <a href="#work" onclick="w3_close()" class="w3-bar-item w3-button">WORK</a>
  <a href="#contact" onclick="w3_close()" class="w3-bar-item w3-button">CONTACT</a>
</nav>

<!-- Header with full-height image -->
<header class="bgimg-1 w3-display-container w3-grayscale-min" id="home">
  <div class="w3-display-left w3-text-white" style="padding:48px">
    <span class="w3-jumbo w3-hide-small">Start something that matters</span><br>
    <span class="w3-xxlarge w3-hide-large w3-hide-medium">Start something that matters</span><br>
    <span class="w3-large">Stop wasting valuable time with projects that just is n't you.</span>
    <p><a href="#about" class="w3-button w3-white w3-padding-large w3-large w3-margin-top w3-opacity w3-hover-opacity-off">Learn more and start today</a></p>
  </div> 
  <div class="w3-display-bottomleft w3-text-grey w3-large" style="padding:24px 48px">
    <i class="fa fa-facebook-official w3-hover-opacity"></i>
    <i class="fa fa-instagram w3-hover-opacity"></i>
    <i class="fa fa-snapchat w3-hover-opacity"></i>
    <i class="fa fa-pinterest-p w3-hover-opacity"></i>
    <i class="fa fa-twitter w3-hover-opacity"></i>
    <i class="fa fa-linkedin w3-hover-opacity"></i>
  </div>
</header>

<!-- About Section -->
<div class="w3-container" style="padding:128px 16px" id="about">
    <h3 class=" w3-center"><b>ABOUT US</b></h3>
  <p class="w3-center w3-large">Key features that we do!</p>
  <div class="w3-row-padding w3-center" style="margin-top:64px">
    <div class="w3-quarter">
      <i class="fa fa-desktop w3-margin-bottom w3-jumbo w3-center"></i>
      <p class="w3-large">Responsive</p>
      <p>We build user Reponsive web pages and web applications.You can check our some work below.</p>
    </div>
    <div class="w3-quarter">
      <i class="fa fa-heart w3-margin-bottom w3-jumbo"></i>
      <p class="w3-large">Passion</p>
      <p>We are passionate about working in the latest technological field and also to help people with all time WEB DEVELOPMENT.</p>
    </div>
    <div class="w3-quarter">
      <i class="fa fa-diamond w3-margin-bottom w3-jumbo"></i>
      <p class="w3-large">Design</p>
      <p>We try to give the web pages responsive and user-friendly design and also getting brief with what the user wants .</p>
    </div>
    <div class="w3-quarter">
      <i class="fa fa-cog w3-margin-bottom w3-jumbo"></i>
      <p class="w3-large">Support</p>
      <p>We are always there to fix.You can also mail us your queries on the link down below.</p>
    </div>
  </div>
</div>

<!-- Promo Section - "We know design" -->
<div class="w3-container w3-light-grey" style="padding:128px 16px">
  <div class="w3-row-padding">
    <div class="w3-col m6">
      <h3>We know design.</h3>
      <p>CLICK BELOW! To check some really nice works</p>
      <p><a href="#work" class="w3-button w3-black"><i class="fa fa-th"> </i> View Our Works</a></p>
    </div>
    <div class="w3-col m6">
        <img class="w3-image w3-round-large" src="./IMAGES/work.png" alt="Buildings" width="700" height="394">
    </div>
  </div>
</div>

<!-- Team Section -->
<div class="w3-container" style="padding:128px 16px" id="team">
    <h3 class="w3-center"><b>THE TEAM</b></h3>
  <p class="w3-center w3-large">The ones who runs through IDEAS</p>
  <div class="w3-row-padding w3-grayscale" style="margin-top:64px">
    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-card">
          <img src="./IMAGES/komal.jpeg" alt="KOMAL" style="width:100%">
        <div class="w3-container">
          <h3>Komal Kumari</h3>
          <p class="w3-opacity">WEB DEVELOPMENT,MCKVIE</p>
          <p>I am a B.TECH Final year student in INFORMATION TECHNOLOGY.<b>I have trained in the field of web application development using PHP from GLOBSYN TRAINING SCHOOL.</b>I like to work in different technologies web application development being my fav.Check out my works and ideas below.</p>
          <p><button class="w3-button w3-light-grey w3-block" onclick="window.location.href='komalcv.html'"><i class="fa fa-envelope"></i> Click-To see my Digital CV</button></p>
        </div>
      </div>
    </div>

    <div class="w3-col l3 m6 w3-margin-bottom">
      <div class="w3-card">
          <img src="./IMAGES/karan.jpeg" alt="KARAN" style="width:89%">
        <div class="w3-container">
          <h3>Karan Yadav</h3>
          <p class="w3-opacity">WEB DEVELOPMENT,MCKVIE</p>
          <p>I am a B.TECH Final year student in INFORMATION TECHNOLOGY.<b>I have trained in the field of web application development using PHP from INTERNSHALA TRAINING SCHOOL.</b>I am enthusiast and hard worker.Please leave a message for our improvement.</p>
          <p><button class="w3-button w3-light-grey w3-block" onclick="window.location.href='karancv.html'"><i class="fa fa-envelope"></i> Click-To see my Digital CV</button></p>
        </div>
      </div>
    </div>
   
   
  </div>
</div>


<!-- Work Section -->
<div class="w3-container" style="padding:128px 16px" id="work">
    <h3 class="w3-center"><b>OUR WORK</b></h3>
  <p class="w3-center w3-large">What we've done for people</p>

  <div class="w3-row-padding" style="margin-top:64px">
    <div class="w3-col l3 m6"  style=" border: 2px solid black ;background-color:lightgoldenrodyellow;width:420px; ">
          <img src="./IMAGES/code_page.jpg" style="width:100%; margin:3px;" onclick="onClick(this)" class="w3-hover-opacity" alt="coding_page">
            <h5><b><u>JAVASCRIPT TUTORIAL</u></b></h5>
        <h5><b>This is a Javascript tutorial page with lot's of new stuff.Hope you like it.</b> </h5>
       <form  action="https://agj8bnz2gkjqjwt5ugezhq-on.drv.tw/www.javascriptenigma.com/public_html/"  target="_blank"><hr />
           <button  style="background-color: lightgreen;" type="submit">Visit page</button></form><hr />
    </div>
    <div class="w3-col l3 m6"  style=" border: 2px solid black ;background-color:lightgoldenrodyellow; margin-left:5px; height:437px;width:420px;">
        <img src="./IMAGES/ecommerce.jpg" style="width:100%" onclick="onClick(this)" class="w3-hover-opacity" alt="coding_page">
            <h5><b><u>E-COMMERCE WEBSITE</u></b></h5> 
        <h5><b>This is an e-commerce mobile selling website,which is user interactive.Hope you like it. </b> </h5>
       <form  action="https://phone-stop.000webhostapp.com/PHP/index.php"  target="_blank"><hr />
           <button  style="background-color: lightgreen;" type="submit">Visit page</button></form><hr />
   
  </div>
 <div class="w3-col l3 m6"  style=" border: 2px solid black ;background-color:lightgoldenrodyellow; margin-left:5px; height:437px;width:420px;">
     <img src="./IMAGES/quiz_game.jpg" style="width:100%; margin:3px;" onclick="onClick(this)" class="w3-hover-opacity" alt="coding_page">
            <h5><b><u>JAVASCRIPT QUIZ GAME</u></b></h5> 
        <h5><b>This is an simple javascript quiz game.Just play along </b> </h5><br /><br />
       <form  action="https://codepen.io/komal2209/pen/qBdzprz"  target="_blank"><hr />
           <button  style="background-color: lightgreen;" type="submit">Visit page</button></form><hr />
   
  </div>
  </div>
   <div class="w3-row-padding" style="margin-top:64px">
      <div class="w3-col l3 m6"  style=" border: 2px solid black ;background-color:lightgoldenrodyellow; margin-left:5px;  height:437px;width:420px;">
          <img src="./IMAGES/quiz_website.jpg" style="width:100%; margin:3px;" onclick="onClick(this)" class="w3-hover-opacity" alt="coding_page">
            <h5><b><u>ONLINE QUIZ WEBSITE</u></b></h5> 
        <h5><b>This is a full Quiz website ,with admin and user sections.Check out it here ,hope you like it. </b> </h5>
        <form  action="https://farthest-increments.000webhostapp.com/index.php"  target="_blank"><hr />
           <button  style="background-color: lightgreen;" type="submit">Visit page</button></form><hr />
   
  </div>
       
       <div class="w3-col l3 m6"  style=" border: 2px solid black ;background-color:lightgoldenrodyellow; margin-left:5px;  height:437px;width:420px;">
           <img src="./IMAGES/job_portal.jpg" style="width:100%; margin:3px;" onclick="onClick(this)" class="w3-hover-opacity" alt="coding_page">
            <h5><b><u>ONLINE JOB PORTAL</u></b></h5> 
        <h5><b>This is an online job portal with 3 features:admin,jobseeker and company.Hope you like it. </b> </h5>
        <form  action="https://extorsive-outboards.000webhostapp.com/index.php"  target="_blank"><hr />
           <button  style="background-color: lightgreen;" type="submit">Visit page</button></form><hr />
   
  </div>
       
         <div class="w3-col l3 m6"  style=" border: 2px solid black ;background-color:lightgoldenrodyellow; margin-left:5px;  height:437px;width:420px;">
             <img src="./IMAGES/more.png" style="width:100%; margin:3px; height:45%;" onclick="onClick(this)" class="w3-hover-opacity" alt="coding_page">
                        <h5><b><u>WORK IN PROGRESS</u></b></h5> 
        <h5><b>Pls stay in touch for more work in coming. </b> </h5>
       
   
  </div>

</div>
<br /><br /><br /><br /><hr />
<!-- Modal for full size images on click-->
<div id="modal01" class="w3-modal w3-black" onclick="this.style.display='none'">
  <span class="w3-button w3-xxlarge w3-black w3-padding-large w3-display-topright" title="Close Modal Image">×</span>
  <div class="w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64">
    <img id="img01" class="w3-image">
    <p id="caption" class="w3-opacity w3-large"></p>
  </div>
</div>

<!-- Skills Section -->
<div class="w3-container w3-light-grey w3-padding-64">
  <div class="w3-row-padding">
    <div class="w3-col m6">
        <h3><b>Our Skills.</b></h3>
      <p>We may be intermediate in this field,but we assure that our growing knowledge is acknowledgeable.
      <ul>
          We have shown our skills over here in the field of:
          <b> <li>FrontEnd</li>
          <li>JavaScript</li>
          <li>PHP</li>
          <li>ASP.NET</li>
          <li>MySQL</li>
          </b>
      </ul>
      </p>
    </div>
    <div class="w3-col m6">
      <p class="w3-wide"><i class="fa fa-desktop w3-margin-right"></i>Web Design</p>
      <div class="w3-grey">
        <div class="w3-container w3-dark-grey w3-center" style="width:85%">85%</div>
      </div>
      <p class="w3-wide"><i class="fa fa-database w3-margin-right"></i>Back End</p>
      <div class="w3-grey">
        <div class="w3-container w3-dark-grey w3-center" style="width:75%">75%</div>
      </div>
     
      </div>
    </div>
  </div>
</div>


<!-- Contact Section -->
<div class="w3-container w3-light-grey" style="padding:128px 16px" id="contact">
    <h3 class="w3-center"><b>CONTACT</b></h3>
  <p class="w3-center w3-large">Lets get in touch. Send us a message:</p>
  <div style="margin-top:48px">
    <p><i class="fa fa-map-marker fa-fw w3-xxlarge w3-margin-right"></i> Kolkata, INDIA</p>
    <p><i class="fa fa-phone fa-fw w3-xxlarge w3-margin-right"></i> Phone: +91 8910812580</p>
     <p><i class="fa fa-envelope fa-fw w3-xxlarge w3-margin-right"> </i> Email: kkumaribest7@gmail.com</p>
    <p><i class="fa fa-envelope fa-fw w3-xxlarge w3-margin-right"> </i> Email: mekaranyadav8@gmail.com</p>
    <br>
    <form name="form1" action="action.php" target="_self" id="action" method="post">
      <p><input class="w3-input w3-border" type="text" placeholder="Name" required name="name" /></p>
      <p><input class="w3-input w3-border" type="text" placeholder="Email" required name="email" /></p>
      <p><input class="w3-input w3-border" type="text" placeholder="Subject" required name="subject" /></p>
      <p><input class="w3-input w3-border" type="text" placeholder="Message" required name="message" /></p>
      <p>
        <button class="w3-button w3-black" type="submit">
          <i class="fa fa-paper-plane"></i> SEND MESSAGE
        </button>
      </p>
    </form>
    <!-- Last image of the page -->
    <img src="./IMAGES/last.jpg" class="w3-image w3-greyscale" style="width:100%;margin-top:48px">
  </div>
</div>

<!-- Footer -->
<footer class="w3-center w3-black w3-padding-64">
  <a href="#home" class="w3-button w3-light-grey"><i class="fa fa-arrow-up w3-margin-right"></i>To the top</a>
  <div class="w3-xlarge w3-section">
    <i class="fa fa-facebook-official w3-hover-opacity"></i>
    <i class="fa fa-instagram w3-hover-opacity"></i>
    <i class="fa fa-snapchat w3-hover-opacity"></i>
    <i class="fa fa-pinterest-p w3-hover-opacity"></i>
    <i class="fa fa-twitter w3-hover-opacity"></i>
    <i class="fa fa-linkedin w3-hover-opacity"></i>
  </div>
  <centre><h5><i>©All rights reserved.</i></h5>
       <h5>Designed by</h5><h3>KOMAL and CO.</h3>
      
  </centre>
</footer>
 
<script src="javascript.js"></script>

</body>
</html>
